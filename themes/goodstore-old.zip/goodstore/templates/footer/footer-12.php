<div class="col-lg-12 footer-widget-area">
    <?php dynamic_sidebar('footer1'); ?>
</div>
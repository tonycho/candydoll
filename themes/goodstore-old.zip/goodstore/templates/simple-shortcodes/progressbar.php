<?php global $jaw_data; ?>
<?php $id = rand(0, 1000); ?>
<div id="jaw_progress" >  
   <?php 
   echo do_shortcode(jaw_template_get_var('content'));?>
</div>

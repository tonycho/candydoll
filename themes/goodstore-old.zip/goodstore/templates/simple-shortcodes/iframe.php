<?php global $jaw_data; ?>

<iframe class="iframe" src="<?php echo esc_url(jaw_template_get_var('src', '')); ?>" height="<?php echo esc_attr(jaw_template_get_var('height', '100')); ?>"></iframe>
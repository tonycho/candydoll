<?php global $jaw_data; ?>
<ul class="nav nav-tabs" > <?php echo do_shortcode(jaw_template_get_var('content')); ?> </ul>
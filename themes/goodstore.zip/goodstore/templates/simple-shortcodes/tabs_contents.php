<?php global $jaw_data; ?>
<div class="tab-content" > <?php echo do_shortcode(jaw_template_get_var('content')); ?> </div>
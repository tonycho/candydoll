<?php global $jaw_data; ?>

<div class="row element-title">
    <div class="col-lg-<?php echo jaw_template_get_var('box_size'); ?>">
        <?php  echo jaw_get_template_part('section_bar', 'simple-shortcodes'); ?>
    </div>
</div>

<?php global $jaw_data; ?>
<div class="sidebar-box">
    <?php
    dynamic_sidebar(jaw_template_get_var('build_sidebar', ''));
    ?>	 
</div>
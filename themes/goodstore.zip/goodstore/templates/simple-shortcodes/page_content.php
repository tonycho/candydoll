<?php global $jaw_data; ?>

<?php 

global $wp_query;
echo do_shortcode(get_the_content());
?>

<?php global $jaw_data; ?>
<div class="jaw-pricing-table-item">
<?php
echo jaw_template_get_var('title');
echo jaw_template_get_var('price');
echo jaw_template_get_var('details');
?>
</div>
<div class="col-lg-3 footer-widget-area">
    <?php dynamic_sidebar('footer1'); ?>
</div>
<div class="col-lg-3 footer-widget-area">
    <?php dynamic_sidebar('footer2'); ?>  
</div>
<div class="col-lg-3 footer-widget-area">
    <?php dynamic_sidebar('footer3'); ?> 
</div>
<div class="col-lg-3 footer-widget-area">
    <?php dynamic_sidebar('footer4'); ?> 
</div>
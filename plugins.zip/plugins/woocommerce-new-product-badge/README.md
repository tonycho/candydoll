WooCommerce New Product Badge
=============================

Displays a 'new' badge on WooCommerce products published in the last x days.